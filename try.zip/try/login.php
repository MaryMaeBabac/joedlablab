<?php
session_start();
require 'conn.php';

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usernameOrEmail = trim($_POST['username_or_email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!$usernameOrEmail) {
        $errors[] = "Username or Email is required.";
    }
    if (!$password) {
        $errors[] = "Password is required.";
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$usernameOrEmail, $usernameOrEmail]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password_hash'])) {
            $_SESSION['user'] = [
                'id' => $user['id'],
                'username' => $user['username'],
                'email' => $user['email'],
                'is_admin' => (bool)$user['is_admin'],
            ];
            header('Location: index.php');
            exit;
        } else {
            $errors[] = "Invalid username/email or password.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Login - Castillanos Backyard</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>
<header>
  <h1>Castillanos Backyard - Login</h1>
</header>
<nav>
  <a href="index.php">Home</a>
  <a href="login.php">Login</a>
  <a href="register.php">Register</a>
</nav>
<div class="container">
  <h2>Login</h2>
  <?php if (!empty($errors)): ?>
    <div class="error">
      <ul>
        <?php foreach ($errors as $e): ?>
          <li><?php echo htmlspecialchars($e); ?></li>
        <?php endforeach; ?>
      </ul>
    </div>
  <?php endif; ?>
  <form method="POST" action="login.php">
    <label for="username_or_email">Username or Email:</label><br />
    <input type="text" id="username_or_email" name="username_or_email" required value="<?php echo htmlspecialchars($_POST['username_or_email'] ?? '') ?>" /><br />
    <label for="password">Password:</label><br />
    <input type="password" id="password" name="password" required /><br />
    <input type="submit" value="Login" />
  </form>
</div>
<footer>
  &copy; <?php echo date("Y"); ?> Castillanos Backyard. All rights reserved.
</footer>
</body>
</html>

<?php
require 'conn.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($password, $user['password_hash'])) {
        // Login successful
        $_SESSION['user'] = [
            'id' => $user['id'],
            'username' => $user['username'],
            'is_admin' => $user['is_admin']
        ];
        
        // Merge guest cart with user cart if exists
        if (isset($_SESSION['guest_cart'])) {
            $_SESSION['cart'] ??= [];
            
            foreach ($_SESSION['guest_cart'] as $product_id => $item) {
                if (isset($_SESSION['cart'][$product_id])) {
                    $_SESSION['cart'][$product_id]['quantity'] += $item['quantity'];
                } else {
                    $_SESSION['cart'][$product_id] = $item;
                }
            }
            
            unset($_SESSION['guest_cart']);
        }
        
        // Redirect to checkout if guest was trying to checkout
        if (isset($_SESSION['guest_checkout'])) {
            unset($_SESSION['guest_checkout']);
            header("Location: checkout.php");
        } else {
            header("Location: index.php");
        }
        exit;
    } else {
        $error = "Invalid username or password";
    }
}
?>

<!-- Rest of your login form remains the same -->