<!DOCTYPE html>
<html>
<head>
    <title>Admin Panel - Castillanos Backyard</title>
    <link rel="stylesheet" href="admin_style.css">
</head>
<body>
    <header class="admin-header">
        <h1>Castillanos Backyard - Admin Panel</h1>
        <nav class="admin-nav">
            <a href="admin.php">Dashboard</a>
            <a href="admin_products.php">Products</a>
            <a href="admin_orders.php">Orders</a>
            <a href="admin_feedback.php">Feedback</a>
            <a href="admin_messages.php">Messages</a>
            <a href="logout.php">Logout</a>
        </nav>
    </header>
    
    <div class="admin-container">
        <!-- Content will be inserted here -->