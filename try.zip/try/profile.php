<?php
session_start();
require 'conn.php';

if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}

// Fetch user info
$userId = $_SESSION['user']['id'];

$stmt = $pdo->prepare("SELECT username, email, profile_image FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch();

// Fetch approved purchases
$stmt = $pdo->prepare("SELECT * FROM purchases WHERE user_id = ? ORDER BY purchase_date DESC");
$stmt->execute([$userId]);
$purchases = $stmt->fetchAll();

// Fetch items for each purchase
foreach ($purchases as &$purchase) {
    $stmt2 = $pdo->prepare("SELECT pi.quantity, pi.price_at_purchase, p.name FROM purchase_items pi JOIN products p ON pi.product_id = p.id WHERE pi.purchase_id = ?");
    $stmt2->execute([$purchase['id']]);
    $purchase['items'] = $stmt2->fetchAll();
}
unset($purchase);

// Handle profile update
$errors = [];
$success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $profile_image = $_FILES['profile_image'] ?? null;

    if (!$username || !$email) {
        $errors[] = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }

    if (empty($errors)) {
        // Handle image upload
        if ($profile_image && $profile_image['error'] == 0) {
            $imagePath = 'uploads/' . basename($profile_image['name']);
            move_uploaded_file($profile_image['tmp_name'], $imagePath);
            $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, profile_image = ? WHERE id = ?");
            $stmt->execute([$username, $email, $imagePath, $userId]);
        } else {
            $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ? WHERE id = ?");
            $stmt->execute([$username, $email, $userId]);
        }
        $success = "Profile updated successfully!";
        // Refresh user data
        $stmt->execute([$userId]);
        $user = $stmt->fetch();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Profile - Castillanos Backyard</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>
<header>
  <h1>Castillanos Backyard - Profile</h1>
</header>
<nav>
  <a href="index.php">Home</a>
  <a href="profile.php">My Profile</a>
  <a href="checkout.php">Cart (<?php echo isset($_SESSION['cart']) ? array_sum(array_column($_SESSION['cart'], 'quantity')) : '0'; ?>)</a>
  <?php if ($_SESSION['user']['is_admin']): ?>
    <a href="admin.php">Admin Panel</a>
  <?php endif; ?>
  <a href="logout.php">Logout</a>
</nav>
<div class="container">
  <section class="profile-info">
    <h2>User Information</h2>
    <form method="POST" enctype="multipart/form-data">
      <label for="username">Username:</label><br />
      <input type="text" id="username" name="username" required value="<?php echo htmlspecialchars($user['username']); ?>" /><br />
      <label for="email">Email:</label><br />
      <input type="email" id="email" name="email" required value="<?php echo htmlspecialchars($user['email']); ?>" /><br />
      <label for="profile_image">Profile Image:</label><br />
      <input type="file" id="profile_image" name="profile_image" accept="image/*" /><br />
      <input type="submit" name="update_profile" value="Update Profile" />
    </form>
    <?php if (!empty($errors)): ?>
      <div class="error">
        <ul>
          <?php foreach ($errors as $e): ?>
            <li><?php echo htmlspecialchars($e); ?></li>
          <?php endforeach; ?>
        </ul>
      </div>