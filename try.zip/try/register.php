<?php
session_start();
require 'conn.php';

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if (!$username) {
        $errors[] = "Username is required.";
    } else {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            $errors[] = "Username already taken.";
        }
    }

    if (!$email) {
        $errors[] = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    } else {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $errors[] = "Email already registered.";
        }
    }

    if (!$password) {
        $errors[] = "Password is required.";
    } elseif ($password !== $confirm_password) {
        $errors[] = "Passwords do not match.";
    } elseif (strlen($password) < 6) {
        $errors[] = "Password must be at least 6 characters.";
    }

    if (empty($errors)) {
        $password_hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)");
        $stmt->execute([$username, $email, $password_hash]);
        $success = "Registration successful. You can now <a href='login.php'>login</a>.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Register - Castillanos Backyard</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>
<header>
  <h1>Castillanos Backyard - Register</h1>
</header>
<nav>
  <a href="index.php">Home</a>
  <a href="login.php">Login</a>
  <a href="register.php">Register</a>
</nav>
<div class="container">
  <h2>Create an Account</h2>
  <?php if (!empty($errors)): ?>
    <div class="error">
      <ul>
        <?php foreach ($errors as $e): ?>
          <li><?php echo htmlspecialchars($e); ?></li>
        <?php endforeach; ?>
      </ul>
    </div>
  <?php endif; ?>
  <?php if ($success): ?>
    <p class="success"><?php echo $success; ?></p>
  <?php else: ?>
  <form method="POST" action="register.php">
    <label for="username">Username:</label><br />
    <input type="text" id="username" name="username" required value="<?php echo htmlspecialchars($_POST['username'] ?? '') ?>" /><br />
    <label for="email">Email:</label><br />
    <input type="email" id="email" name="email" required value="<?php echo htmlspecialchars($_POST['email'] ?? '') ?>" /><br />
    <label for="password">Password:</label><br />
    <input type="password" id="password" name="password" required /><br />
    <label for="confirm_password">Confirm Password:</label><br />
    <input type="password" id="confirm_password" name="confirm_password" required /><br />
    <input type="submit" value="Register" />
  </form>
  <?php endif; ?>
</div>
<footer>
  &copy; <?php echo date("Y"); ?> Castillanos Backyard. All rights reserved.
</footer>
</body>
</html>