<?php
$conn=mysqli_connect("localhost","root","");
$db=mysqli_select_db($conn,"dashboard_db");


/*
session_start();

// Database connection settings
$host = 'localhost';
$dbname = 'poultry';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ATTR_ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Could not connect to the database. Please try again later.");
}

// Initialize guest cart if not exists
if (!isset($_SESSION['user']) && !isset($_SESSION['guest_cart'])) {
    $_SESSION['guest_cart'] = [];
}
    */
?>