other option dashboard lng m click
<?php
require 'conn.php';
$servername = "localhost"; // Change to your server if needed
$username = "root"; // Default username for XAMPP/MAMP
$password = ""; // Default password for XAMPP/MAMP is empty
$dbname = "dashboard_db"; // Name of your database

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM sales ORDER BY date_order ASC LIMIT 30";
$result = $conn->query($sql);



$sales_data = [];
while ($row = $result->fetch_assoc()) {
    $sales_data[] = ['date_order' => $row['date_order'], 'total_price' => $row['total_price'], 'product_name' => $row['product_name'], 'quantity' => $row['quantity']];
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>castillano</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --primary: #27ae60;
            --secondary: #2c3e50;
            --accent: #e74c3c;
            --light: #ecf0f1;
            --dark: #34495e;
            --text: #333;
            --text-light: #7f8c8d;
            --white: #fff;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            display: flex;
            background-color: #f5f7fa;
            color: var(--text);
        }
        
        /* Sidebar Styles */
        .sidebar {
            width: 250px;
            background-color: var(--secondary);
            color: var(--white);
            height: 100vh;
            padding: 20px 0;
            position: fixed;
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            margin-bottom: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            text-align: center;
        }
        
        .sidebar-menu {
            list-style: none;
        }
        
        .menu-item {
            padding: 12px 20px;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            border-left: 3px solid transparent;
        }
        
        .menu-item i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .menu-item:hover, .menu-item.active {
            background-color: rgba(255,255,255,0.1);
            border-left: 3px solid var(--primary);
        }          
        .a {
                text-decoration: none;
                color: white;
        }
        
        /* Main Content Styles */
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
        }
        
        .top-nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background-color: var(--white);
            padding: 15px 25px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .user-profile {
            display: flex;
            align-items: center;
        }
        
        .user-profile img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }
        
        
        .dashboard-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .card {
            background-color: var(--white);
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .card-icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 20px;
            background-color: var(--primary);
        }
        
        .card-value {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 5px;
        }
        
        .card-title {
            color: var(--text-light);
            font-size: 14px;
        }
        
      
        .analysis-section {
            background-color: var(--white);
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }
        
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .section-title {
            font-size: 18px;
            font-weight: 600;
        }
        
        .chart-row {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .chart-container {
            flex: 1;
            height: 300px;
            position: relative;
            background-color: var(--white);
            border-radius: 8px;
            padding: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }
        
        .chart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .chart-title {
            font-size: 16px;
            font-weight: 600;
            color: var(--dark);
        }
        
        
        .orders-section {
            background-color: var(--white);
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .table th, .table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        .table th {
            background-color: #f9f9f9;
            color: var(--text-light);
            font-weight: 600;
        }
        
        .status {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .status-pending {
            background-color: #fff4e5;
            color: #f39c12;
        }
        
        .status-completed {
            background-color: #e6f7ee;
            color: #27ae60;
        }
        
        .status-cancelled {
            background-color: #fee;
            color: #e74c3c;
        }
        
       
        .messages-section {
            background-color: var(--white);
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .message {
            padding: 15px 0;
            border-bottom: 1px solid #eee;
        }
        
        .message:last-child {
            border-bottom: none;
        }
        
        .message-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        
        .message-sender {
            font-weight: 600;
            display: flex;
            align-items: center;
        }
        
        .message-avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background-color: #eee;
            margin-right: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .message-time {
            color: var(--text-light);
            font-size: 12px;
        }
        
        .message-content {
            color: var(--text);
            margin-bottom: 10px;
        }
        
        .message-reply {
            display: none;
            margin-top: 15px;
            background-color: #f9f9f9;
            padding: 15px;
            border-radius: 8px;
        }
        
        .message-reply textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            resize: vertical;
            min-height: 80px;
            margin-bottom: 10px;
        }
        
        .message-reply-actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }
        
        .btn {
            padding: 8px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 600;
            font-size: 14px;
        }
        
        .btn-primary {
            background-color: var(--primary);
            color: white;
        }
        
        .btn-outline {
            background-color: transparent;
            border: 1px solid var(--text-light);
            color: var(--text-light);
        }
        
        .unread {
            background-color: #f5f9ff;
            border-left: 3px solid var(--primary);
            padding-left: 10px;
        }
        
        .reply-btn {
            color: var(--primary);
            background: none;
            border: none;
            cursor: pointer;
            font-size: 13px;
            padding: 0;
        }
        
        /* Responsive Adjustments */
        @media (max-width: 992px) {
            .chart-row {
                flex-direction: column;
            }
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
            }
            
            .sidebar-header span, .menu-item span {
                display: none;
            }
            
            .menu-item {
                justify-content: center;
            }
            
            .menu-item i {
                margin-right: 0;
                font-size: 20px;
            }
            
            .main-content {
                margin-left: 80px;
            }
  
        }
    </style>
</head>
<body>
  
    <div class="sidebar">
        <div class="sidebar-header">
            <h3>Castillano's Backyard</h3>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-item active">
                <i class="fas fa-tachometer-alt"></i>
                <a href="admin.php" style=>Dashboard</a>
            </li>
            <li class="menu-item">
                <i class="fas fa-box"></i>
                <a href="product.php">Products</a>
            </li>
        </ul>
    </div>
    
    
    <div class="main-content">
       
        <div class="top-nav">
            <h2>Dashboard</h2>
            <div class="user-profile">
                <img src="https://via.placeholder.com/40" alt="User">
                <span>Admin</span>
            </div>
        </div>
        
      
        <div class="dashboard-cards">
            <div class="card">
                <div class="card-header">
                    <div>
                        <div class="card-title">Total Sales</div>
                        <?php
                        $sql_total_sales = "SELECT SUM(total_price) AS total_sales FROM sales";
                        $result_total_sales = $conn->query($sql_total_sales);
                        $total_products_sales = $result_total_sales->fetch_assoc()['total_sales'];
                        ?>
                        <div class="card-value"><?php echo $total_products_sales; ?></div>
                    </div>
                    <div class="card-icon">
                        <i class="fas fa-receipt"></i>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <div>
                        <div class="card-title">Total Products Sold</div>
                        <?php
                        $sql_total_products = "SELECT SUM(quantity) AS total_products_sold FROM sales";
                        $result_total_products = $conn->query($sql_total_products);
                        $total_products_sold = $result_total_products->fetch_assoc()['total_products_sold'];
                        ?>
                        <div class="card-value"><?php echo $total_products_sold; ?></div>
                    </div>
                    <div class="card-icon">
                        <i class="fas fa-shopping-cart"></i>
                    </div>
                </div>
            </div>

        </div>
        
       
        <div class="analysis-section">
            <div class="section-header">
                <div class="section-title">Sales Analysis Report</div>
            </div>
            
            <div class="chart-row">
                <div class="chart-container">
                    <div class="chart-header">
                        <div class="chart-title">Monthly Sales (₱)</div>
                    </div>
                    <canvas id="salesChart"></canvas>
                </div>
                
                <div class="chart-container">
                    <div class="chart-header">
                        <div class="chart-title">Product Category Sales</div>
                    </div>
                    <canvas id="categoryChart"></canvas>
                </div>
            </div>
            <div class="chart-row">
        
                <div class="chart-container">
                    <div class="chart-header">
                        <div class="chart-title">Top Selling Products</div>
                    </div>
                    <canvas id="productChart"></canvas>
                </div>
            
            </div>
        </div>
        
        
        <div class="orders-section">
            <div class="section-header">
                <div class="section-title">Recent Orders</div>
                <a href="#">View All</a>
            </div>
            <table class="table">
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Product</th>
                        <th>Amount</th>
                        <th>Price</th>
                        <th>Date of Order</th>
                    </tr>
                </thead>
                <?php
                $records = mysqli_query($conn, "SELECT * FROM sales");
                while ($get_records = mysqli_fetch_array($records)) {
                    ?>
                    <tr>
                        <td><?php echo $get_records['id']; ?></td>
                        <td><?php echo $get_records['product_name']; ?></td>
                        <td><?php echo $get_records['quantity']; ?></td>
                        <td><?php echo $get_records['total_price']; ?></td>
                        <td><?php echo $get_records['date_order']; ?></td>
                    </tr>
                    <?php
                }
                ?>
            </tbody>
            </table>
        </div>
        
        
    </div>

    <script>
        // Get the sales data from PHP
        const salesData = <?php echo json_encode($sales_data); ?>;

        // Extract labels (dates) and data (total price)
        const salesMap = salesData.reduce((acc, item) => {
            if (acc[item.date_order]) {
            acc[item.date_order] += parseFloat(item.total_price);
            } else {
            acc[item.date_order] = parseFloat(item.total_price);
            }
            return acc;
        }, {});

        const labels = Object.keys(salesMap);
        const amounts = Object.values(salesMap);
        const productMap = salesData.reduce((acc, item) => {
            if (acc[item.product_name]) {
            acc[item.product_name] += parseInt(item.quantity);
            } else {
            acc[item.product_name] = parseInt(item.quantity);
            }
            return acc;
        }, {});

        const product = Object.keys(productMap);
        const quantity = Object.values(productMap);
        
        document.addEventListener('DOMContentLoaded', function() {
            
            const salesCtx = document.getElementById('salesChart').getContext('2d');
            const salesChart = new Chart(salesCtx, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Sales (₱)',
                        data: amounts,
                        backgroundColor: 'rgba(39, 174, 96, 0.7)',
                        borderColor: 'rgba(39, 174, 96, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                drawBorder: false
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                }
            });
            
           
            const categoryCtx = document.getElementById('categoryChart').getContext('2d');
            const categoryChart = new Chart(categoryCtx, {
                type: 'pie',
                data: {
                    labels: product,
                    datasets: [{
                        data: quantity,
                        backgroundColor: [
                            'rgba(39, 174, 96, 0.7)',
                            'rgba(52, 152, 219, 0.7)',
                            'rgba(155, 89, 182, 0.7)',
                            'rgba(241, 196, 15, 0.7)',
                            'rgba(231, 76, 60, 0.7)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'right'
                        }
                    }
                }
            });
            

            const productCtx = document.getElementById('productChart').getContext('2d');
            const productChart = new Chart(productCtx, {
                type: 'bar',
                data: {
                    labels: product,
                    datasets: [{
                        data: amounts,
                        backgroundColor: 'rgba(52, 152, 219, 0.7)',
                        borderColor: 'rgba(52, 152, 219, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    indexAxis: 'y',
                    scales: {
                        x: {
                            beginAtZero: true,
                            grid: {
                                drawBorder: false
                            }
                        },
                        y: {
                            grid: {
                                display: false
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                }
            });
        
            
        
            
            
            document.getElementById('timePeriod').addEventListener('change', function() {
                const period = this.value;
               
                let salesData, categoryData, productData, paymentData;
                
                if (period === '7') {
                    salesChart.data.labels = ['Day 1', 'Day 2', 'Day 3', 'Day 4', 'Day 5', 'Day 6', 'Day 7'];
                    salesData = [4000, 6000, 3500, 7000, 5500, 8000, 6500];
                    categoryData = [40, 20, 15, 15, 10];
                    productData = [35, 12, 18, 8, 5];
                    paymentData = [50, 25, 20, 5];
                } else if (period === '30') {
                    salesChart.data.labels = ['Week 1', 'Week 2', 'Week 3', 'Week 4'];
                    salesData = [15000, 22000, 18000, 25000];
                    categoryData = [35, 25, 20, 15, 5];
                    productData = [120, 45, 60, 30, 25];
                    paymentData = [45, 30, 20, 5];
                } else {
                    salesChart.data.labels = ['Month 1', 'Month 2', 'Month 3'];
                    salesData = [45000, 55000, 50000];
                    categoryData = [30, 30, 25, 10, 5];
                    productData = [350, 120, 150, 80, 50];
                    paymentData = [40, 35, 20, 5];
                }
                
               
                salesChart.data.datasets[0].data = salesData;
                categoryChart.data.datasets[0].data = categoryData;
                productChart.data.datasets[0].data = productData;
                paymentChart.data.datasets[0].data = paymentData;
                
                salesChart.update();
                categoryChart.update();
                productChart.update();
                paymentChart.update();
            });
        });

 
        function toggleReply(id) {
            const replyBox = document.getElementById(`reply-${id}`);
            replyBox.style.display = replyBox.style.display === 'block' ? 'none' : 'block';
        }

        function sendReply(id) {
            const replyText = document.querySelector(`#reply-${id} textarea`).value;
            if (replyText.trim() === '') {
                alert('Please enter a reply message');
                return;
            }
            
           
            console.log(`Reply to message ${id}:`, replyText);
            
           
            alert('Reply sent successfully!');
            document.querySelector(`#reply-${id} textarea`).value = '';
            toggleReply(id);
            
          
            const message = document.querySelector(`#reply-${id}`).parentElement;
            message.classList.remove('unread');
        }
    </script>
</body>
</html>