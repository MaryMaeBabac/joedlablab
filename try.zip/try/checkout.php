<?php
session_start();
require 'conn.php';

if (!isset($_SESSION['cart']) || count($_SESSION['cart']) === 0) {
  $emptyCart = true;
} else {
  $emptyCart = false;
}

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!isset($_SESSION['user'])) {
    $errors[] = "You must be logged in to complete checkout.";
  }
  if ($emptyCart) {
    $errors[] = "Your cart is empty.";
  }
  if (empty($errors)) {
    $userId = $_SESSION['user']['id'];
    $items = $_SESSION['cart'];
    $total = 0.0;
    foreach ($items as $item) {
      $price = $item['product']['price'];
      $qty = $item['quantity'];
      $total += $price * $qty;
    }
    try {
      $pdo->beginTransaction();

      $stmt = $pdo->prepare("INSERT INTO purchases (user_id, total, purchase_date) VALUES (?, ?, NOW())");
      $stmt->execute([$userId, $total]);
      $purchaseId = $pdo->lastInsertId();

      $stmtItem = $pdo->prepare("INSERT INTO purchase_items (purchase_id, product_id, quantity, price_at_purchase) VALUES (?, ?, ?, ?)");

      foreach ($items as $item) {
        $stmtItem->execute([$purchaseId, $item['product']['id'], $item['quantity'], $item['product']['price']]);
      }
      $pdo->commit();
      unset($_SESSION['cart']);
      $success = "Purchase completed successfully!";
      $emptyCart = true;
    } catch (Exception $e) {
      $pdo->rollBack();
      $errors[] = 'Purchase failed: ' . $e->getMessage();
    }
  }
}

$cartTotal = 0.0;
$cartQty = 0;
if (!$emptyCart) {
  foreach ($_SESSION['cart'] as $c) {
    $cartTotal += $c['product']['price'] * $c['quantity'];
    $cartQty += $c['quantity'];
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Checkout - Castillanos Backyard</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>
<header>
  <h1>Castillanos Backyard - Checkout</h1>
</header>
<nav>
  <a href="index.php">Home</a>
  <?php if (isset($_SESSION['user'])): ?>
    <a href="profile.php">My Profile</a>
    <a href="checkout.php">Cart (<?php echo $cartQty; ?>)</a>
    <?php if ($_SESSION['user']['is_admin']): ?>
      <a href="admin.php">Admin Panel</a>
    <?php endif; ?>
    <a href="logout.php">Logout</a>
  <?php else: ?>
    <a href="register.php">Register</a>
    <a href="login.php">Login</a>
  <?php endif; ?>
</nav>
<div class="container">
  <h2>Your Cart</h2>
  <?php if ($emptyCart): ?>
    <p>Your cart is empty. <a href="index.php">Go shopping</a>.</p>
  <?php else: ?>
    <div>
      <?php foreach ($_SESSION['cart'] as $item): ?>
        <div class="cart-item">
          <span><?php echo htmlspecialchars($item['product']['name']); ?> x<?php echo $item['quantity']; ?></span>
          <span>$<?php echo number_format($item['product']['price'] * $item['quantity'], 2); ?></span>
        </div>
      <?php endforeach; ?>
      <hr />
      <p><strong>Total:</strong> $<?php echo number_format($cartTotal, 2); ?></p>
    </div>
    <?php if (!empty($errors)): ?>
      <div class="error">
        <ul>
          <?php foreach ($errors as $e): ?>
            <li><?php echo htmlspecialchars($e); ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>
    <?php if ($success): ?>
      <p class="success"><?php echo $success; ?></p>
    <?php endif; ?>
    <?php if (!isset($_SESSION['user'])): ?>
      <p>You must <a href="login.php">login</a> or <a href="register.php">register</a> to complete your purchase.</p>
    <?php else: ?>
      <?php if (!$success): ?>
      <form method="POST" action="checkout.php">
        <input type="submit" value="Complete Purchase" />
      </form>
      <?php endif; ?>
    <?php endif; ?>
  <?php endif; ?>
</div>
<footer>
  &copy; <?php echo date("Y"); ?> Castillanos Backyard. All rights reserved.
</footer>
</body>
</html>