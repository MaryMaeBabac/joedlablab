<?php
require 'conn.php';

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

// Handle checkout
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['checkout'])) {
    $user_id = $_SESSION['user']['id'];
    $total = 0;
    
    // Calculate total
    foreach ($_SESSION['cart'] as $item) {
        $total += $item['product']['price'] * $item['quantity'];
    }
    
    // Create order
    $stmt = $pdo->prepare("INSERT INTO orders (user_id, total_amount) VALUES (?, ?)");
    $stmt->execute([$user_id, $total]);
    $order_id = $pdo->lastInsertId();
    
    // Add order items
    $stmt = $pdo->prepare("INSERT INTO order_items (order_id, product_id, quantity, price_at_order) VALUES (?, ?, ?, ?)");
    
    foreach ($_SESSION['cart'] as $product_id => $item) {
        $stmt->execute([$order_id, $product_id, $item['quantity'], $item['product']['price']]);
    }
    
    // Clear cart and show success message
    unset($_SESSION['cart']);
    $_SESSION['message'] = "Thank you for your order! Your order ID is #$order_id";
    header("Location: orders.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Your Cart - Castillanos Backyard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="container">
        <h2>Your Shopping Cart</h2>
        
        <?php if (isset($_SESSION['message'])): ?>
            <div class="message"><?php echo $_SESSION['message']; ?></div>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>
        
        <?php if (empty($_SESSION['cart'])): ?>
            <p>Your cart is empty. <a href="products.php">Browse products</a></p>
        <?php else: ?>
            <table class="cart-table">
                <tr>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                </tr>
                
                <?php 
                $cart_total = 0;
                foreach ($_SESSION['cart'] as $item): 
                    $item_total = $item['product']['price'] * $item['quantity'];
                    $cart_total += $item_total;
                ?>
                    <tr>
                        <td><?php echo $item['product']['name']; ?></td>
                        <td>₱<?php echo number_format($item['product']['price'], 2); ?></td>
                        <td><?php echo $item['quantity']; ?></td>
                        <td>₱<?php echo number_format($item_total, 2); ?></td>
                    </tr>
                <?php endforeach; ?>
                
                <tr class="total-row">
                    <td colspan="3"><strong>Total:</strong></td>
                    <td><strong>₱<?php echo number_format($cart_total, 2); ?></strong></td>
                </tr>
            </table>
            
            <form method="post" class="checkout-form">
                <button type="submit" name="checkout" class="checkout-btn">Proceed to Checkout</button>
            </form>
        <?php endif; ?>
    </div>
    
    <?php include 'footer.php'; ?>
</body>
</html>

<?php
require 'conn.php';

// Determine which cart to use
$cart = isset($_SESSION['user']) ? ($_SESSION['cart'] ?? []) : ($_SESSION['guest_cart'] ?? []);
$is_guest = !isset($_SESSION['user']);

// Handle checkout
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['checkout'])) {
    if ($is_guest) {
        // Redirect guest to login/register with cart preservation
        $_SESSION['guest_checkout'] = true;
        $_SESSION['message'] = "Please login or register to complete your order";
        header("Location: login.php");
        exit;
    }
    
    // Existing checkout logic for registered users...
}

// Calculate cart totals
$cart_total = 0;
$cart_items = 0;

foreach ($cart as $item) {
    $cart_total += $item['product']['price'] * $item['quantity'];
    $cart_items += $item['quantity'];
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Your Cart - Castillanos Backyard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="container">
        <h2>Your Shopping Cart</h2>
        
        <?php if (empty($cart)): ?>
            <div class="empty-cart">
                <p>Your cart is empty</p>
                <a href="products.php" class="btn">Browse Products</a>
            </div>
        <?php else: ?>
            <div class="cart-items">
                <?php foreach ($cart as $product_id => $item): ?>
                    <div class="cart-item">
                        <img src="<?php echo $item['product']['image_path'] ?? 'images/default_product.jpg'; ?>" alt="<?php echo htmlspecialchars($item['product']['name']); ?>">
                        <div class="item-details">
                            <h3><?php echo htmlspecialchars($item['product']['name']); ?></h3>
                            <p>₱<?php echo number_format($item['product']['price'], 2); ?></p>
                            
                            <form method="post" action="update_cart.php" class="quantity-form">
                                <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
                                <label>Qty:</label>
                                <input type="number" name="quantity" value="<?php echo $item['quantity']; ?>" min="1" max="<?php echo $item['product']['stock_quantity']; ?>">
                                <button type="submit" name="update">Update</button>
                                <button type="submit" name="remove">Remove</button>
                            </form>
                        </div>
                        <div class="item-total">
                            ₱<?php echo number_format($item['product']['price'] * $item['quantity'], 2); ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <div class="cart-summary">
                <h3>Order Summary</h3>
                <div class="summary-row">
                    <span>Items (<?php echo $cart_items; ?>):</span>
                    <span>₱<?php echo number_format($cart_total, 2); ?></span>
                </div>
                <div class="summary-row">
                    <span>Delivery:</span>
                    <span>₱0.00</span> <!-- Free delivery for now -->
                </div>
                <div class="summary-row total">
                    <span>Total:</span>
                    <span>₱<?php echo number_format($cart_total, 2); ?></span>
                </div>
                
                <form method="post" action="cart.php">
                    <?php if ($is_guest): ?>
                        <p class="guest-notice">You need to login or register to checkout</p>
                        <div class="checkout-options">
                            <a href="login.php" class="btn">Login</a>
                            <a href="register.php" class="btn">Register</a>
                            <a href="products.php" class="btn">Continue Shopping</a>
                        </div>
                    <?php else: ?>
                        <button type="submit" name="checkout" class="btn checkout-btn">Proceed to Checkout</button>
                    <?php endif; ?>
                </form>
            </div>
        <?php endif; ?>
    </div>
    
    <?php include 'footer.php'; ?>
</body>
</html>