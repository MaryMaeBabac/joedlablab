other option dashboard lng m click
<?php
require 'conn.php';
$servername = "localhost"; // Change to your server if needed
$username = "root"; // Default username for XAMPP/MAMP
$password = ""; // Default password for XAMPP/MAMP is empty
$dbname = "dashboard_db"; // Name of your database

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $date_order = $_POST['date_order'];
    $product_name = $_POST['product_name'];
    $quantity = $_POST['quantity'];
    $total_price = $_POST['total_price'];

    $stmt = $conn->prepare("INSERT INTO sales (date_order, product_name, quantity, total_price) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssii", $date_order, $product_name, $quantity, $total_price);

    if ($stmt->execute()) {
        ?>
        <script>
            alert('Record added successfully!'); 
            window.location.href='admin.php';
        </script>";
        <?php
    } else {
        ?>
         <script>
            alert('ERROR!!'); 
            window.location.href='product.php';
        </script>";
        <?php
    }

    $stmt->close();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>castillano</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        form {
            max-width: 400px;
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            background-color: #f9f9f9;
        }
        form div {
            margin-bottom: 15px;
        }
        form label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        form input, form button {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        form button {
            background-color: #27ae60;
            color: white;
            font-weight: bold;
            cursor: pointer;
        }
        form button:hover {
            background-color: #219150;
        }
        :root {
            --primary: #27ae60;
            --secondary: #2c3e50;
            --accent: #e74c3c;
            --light: #ecf0f1;
            --dark: #34495e;
            --text: #333;
            --text-light: #7f8c8d;
            --white: #fff;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            display: flex;
            background-color: #f5f7fa;
            color: var(--text);
        }
        
        /* Sidebar Styles */
        .sidebar {
            width: 250px;
            background-color: var(--secondary);
            color: var(--white);
            height: 100vh;
            padding: 20px 0;
            position: fixed;
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            margin-bottom: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            text-align: center;
        }
        
        .sidebar-menu {
            list-style: none;
        }
        
        .menu-item {
            padding: 12px 20px;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            border-left: 3px solid transparent;
        }
        
        .menu-item i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .menu-item:hover, .menu-item.active {
            background-color: rgba(255,255,255,0.1);
            border-left: 3px solid var(--primary);
        }          
        .a {
                text-decoration: none;
                color: white;
        }
        
        /* Main Content Styles */
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
        }
        
        .top-nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background-color: var(--white);
            padding: 15px 25px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .user-profile {
            display: flex;
            align-items: center;
        }
        
        .user-profile img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }
        
        
        .dashboard-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .card {
            background-color: var(--white);
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .card-icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 20px;
            background-color: var(--primary);
        }
        
        .card-value {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 5px;
        }
        
        .card-title {
            color: var(--text-light);
            font-size: 14px;
        }
        
      
        .analysis-section {
            background-color: var(--white);
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }
        
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .section-title {
            font-size: 18px;
            font-weight: 600;
        }
        
        .chart-row {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .chart-container {
            flex: 1;
            height: 300px;
            position: relative;
            background-color: var(--white);
            border-radius: 8px;
            padding: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }
        
        .chart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .chart-title {
            font-size: 16px;
            font-weight: 600;
            color: var(--dark);
        }
        
        
        .orders-section {
            background-color: var(--white);
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .table th, .table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        .table th {
            background-color: #f9f9f9;
            color: var(--text-light);
            font-weight: 600;
        }
        
        .status {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .status-pending {
            background-color: #fff4e5;
            color: #f39c12;
        }
        
        .status-completed {
            background-color: #e6f7ee;
            color: #27ae60;
        }
        
        .status-cancelled {
            background-color: #fee;
            color: #e74c3c;
        }
        
       
        .messages-section {
            background-color: var(--white);
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .message {
            padding: 15px 0;
            border-bottom: 1px solid #eee;
        }
        
        .message:last-child {
            border-bottom: none;
        }
        
        .message-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        
        .message-sender {
            font-weight: 600;
            display: flex;
            align-items: center;
        }
        
        .message-avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background-color: #eee;
            margin-right: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .message-time {
            color: var(--text-light);
            font-size: 12px;
        }
        
        .message-content {
            color: var(--text);
            margin-bottom: 10px;
        }
        
        .message-reply {
            display: none;
            margin-top: 15px;
            background-color: #f9f9f9;
            padding: 15px;
            border-radius: 8px;
        }
        
        .message-reply textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            resize: vertical;
            min-height: 80px;
            margin-bottom: 10px;
        }
        
        .message-reply-actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }
        
        .btn {
            padding: 8px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 600;
            font-size: 14px;
        }
        
        .btn-primary {
            background-color: var(--primary);
            color: white;
        }
        
        .btn-outline {
            background-color: transparent;
            border: 1px solid var(--text-light);
            color: var(--text-light);
        }
        
        .unread {
            background-color: #f5f9ff;
            border-left: 3px solid var(--primary);
            padding-left: 10px;
        }
        
        .reply-btn {
            color: var(--primary);
            background: none;
            border: none;
            cursor: pointer;
            font-size: 13px;
            padding: 0;
        }
        
        /* Responsive Adjustments */
        @media (max-width: 992px) {
            .chart-row {
                flex-direction: column;
            }
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
            }
            
            .sidebar-header span, .menu-item span {
                display: none;
            }
            
            .menu-item {
                justify-content: center;
            }
            
            .menu-item i {
                margin-right: 0;
                font-size: 20px;
            }
            
            .main-content {
                margin-left: 80px;
            }
        

        }
    </style>
</head>
<body>
  
    <div class="sidebar">
        <div class="sidebar-header">
            <h3>Castillano's Backyard</h3>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-item active">
                <i class="fas fa-tachometer-alt"></i>
                <a href="admin.php" style=>Dashboard</a>
            </li>
            <li class="menu-item">
                <i class="fas fa-box"></i>
                <a href="product.php">Products</a>
            </li>
        </ul>
    </div>
    
    
    <div class="main-content">
       
        <div class="top-nav">
            <h2>Add Products</h2>
            <div class="user-profile">
                <img src="https://via.placeholder.com/40" alt="User">
                <span>Admin</span>
            </div>
        </div>
        
      
        <div class="dashboard-cards">
   
    </div> 
    <form method="POST" action="">
        <div>
            <label for="date_order">Date of Order:</label>
            <input type="date" id="date_order" name="date_order" required>
        </div>
        <div>
            <label for="product_name">Product Name:</label>
            <select id="product_name" name="product_name" required>
            <option value="" disabled selected>Select a product</option>
            <option value="Egg">Egg</option>
            <option value="Live Pig">Live Pig</option>
            <option value="Live Chicken">Live Chicken</option>
            <option value="A.I">Artificial Insemenation</option>
            </select>
        </div>
        <div>
            <label for="quantity">Quantity:</label>
            <input type="number" id="quantity" name="quantity" min="1" required>
        </div>
        <div>
            <label for="total_price">Total Price:</label>
            <input type="number" id="total_price" name="total_price" min="0" required>
        </div>
        <button type="submit">Add Record</button>
    </form>


</body>
</html>