<?php
require 'conn.php';

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

// Get user's orders
$stmt = $pdo->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY order_date DESC");
$stmt->execute([$_SESSION['user']['id']]);
$orders = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Orders - Castillanos Backyard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="container">
        <h2>My Orders</h2>
        
        <?php if (isset($_SESSION['message'])): ?>
            <div class="message"><?php echo $_SESSION['message']; ?></div>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>
        
        <?php if (empty($orders)): ?>
            <p>You haven't placed any orders yet. <a href="products.php">Browse products</a></p>
        <?php else: ?>
            <div class="orders-list">
                <?php foreach ($orders as $order): ?>
                    <div class="order-card">
                        <h3>Order #<?php echo $order['id']; ?></h3>
                        <p>Date: <?php echo $order['order_date']; ?></p>
                        <p>Status: <?php echo ucfirst($order['status']); ?></p>
                        <p>Total: ₱<?php echo number_format($order['total_amount'], 2); ?></p>
                        
                        <h4>Items:</h4>
                        <?php
                        $stmt = $pdo->prepare("
                            SELECT p.name, oi.quantity, oi.price_at_order 
                            FROM order_items oi
                            JOIN products p ON oi.product_id = p.id
                            WHERE oi.order_id = ?
                        ");
                        $stmt->execute([$order['id']]);
                        $items = $stmt->fetchAll();
                        ?>
                        
                        <ul class="order-items">
                            <?php foreach ($items as $item): ?>
                                <li>
                                    <?php echo $item['quantity']; ?> x <?php echo $item['name']; ?> 
                                    (₱<?php echo number_format($item['price_at_order'], 2); ?> each)
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    
    <?php include 'footer.php'; ?>
</body>
</html>