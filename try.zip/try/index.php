<?php
require_once 'conn.php';


session_start();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['login'])) handleLogin();
    if (isset($_POST['register'])) handleRegister();
    if (isset($_POST['checkout'])) handleCheckout();
}

// Get current user
$user = $_SESSION['user'] ?? null;
$cart = $_SESSION['cart'] ?? [];
?>
<!DOCTYPE html>
<html>
<head>
    <title>FarmFresh - Farm Products</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>FarmFresh</h1>
        <nav>
            <?php if ($user): ?>
                <span>Welcome, <?= htmlspecialchars($user['name']) ?>!</span>
                <a href="?logout">Logout</a>
                <a href="?page=cart">Cart (<?= count($cart) ?>)</a>
            <?php else: ?>
                <a href="?page=login">Login</a>
                <a href="?page=register">Register</a>
            <?php endif; ?>
        </nav>
    </header>

    <main>
        <?php
        $page = $_GET['page'] ?? 'home';
        switch ($page) {
            case 'products': include 'views/products.php'; break;
            case 'cart': include 'views/cart.php'; break;
            case 'checkout': include 'views/checkout.php'; break;
            case 'login': include 'views/login.php'; break;
            case 'register': include 'views/register.php'; break;
            default: include 'TRY/index.html';
        }
        ?>
    </main>
</body>
</html>