<?php
include '../conn.php';
$orders = $conn->query("SELECT * FROM order_items ORDER BY created_at DESC");
?>

<h2>Customer Orders</h2>
<table border="1" cellpadding="8" cellspacing="0">
  <thead>
    <tr>
      <th>Order ID</th><th>Customer</th><th>Total</th><th>Payment</th><th>Status</th><th>Ordered on</th>
    </tr>
  </thead>
  <tbody>
    <?php while ($order = $orders->fetch_assoc()): ?>
    <tr>
      <td><?= $order['id'] ?></td>
      <td><?= htmlspecialchars($order['customer_name']) ?></td>
      <td>₱<?= number_format($order['total'], 2) ?></td>
      <td><?= $order['payment_method'] ?></td>
      <td><?= $order['status'] ?></td>
      <td><?= $order['created_at'] ?></td>
    </tr>
    <?php endwhile; ?>
  </tbody>
</table>