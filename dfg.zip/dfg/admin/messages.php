<?php
include '../conn.php';
$messages = $conn->query("SELECT messages.*, users.name FROM messages JOIN users ON messages.user_id = users.id ORDER BY sent_at DESC");
?>

<h2>Customer Messages</h2>
<table border="1" cellpadding="8" cellspacing="0">
  <thead>
    <tr>
      <th>From</th><th>Message</th><th>Sent</th><th>Sentiment</th><th>Reply</th><th>Respond</th>
    </tr>
  </thead>
  <tbody>
    <?php while ($msg = $messages->fetch_assoc()): ?>
    <tr>
      <td><?= htmlspecialchars($msg['name']) ?></td>
      <td><?= htmlspecialchars($msg['content']) ?></td>
      <td><?= $msg['sent_at'] ?></td>
      <td>
        <strong><?= ucfirst($msg['sentiment_label']) ?></strong><br>
        Score: <?= $msg['sentiment_score'] ?>
      </td>
      <td><?= htmlspecialchars($msg['reply']) ?></td>
      <td>
        <form method="POST" action="../backend/save_reply.php">
          <input type="hidden" name="message_id" value="<?= $msg['id'] ?>">
          <input type="text" name="reply" placeholder="Your reply" required>
          <button type="submit">Send</button>
        </form>
      </td>
    </tr>
    <?php endwhile; ?>
  </tbody>
</table>