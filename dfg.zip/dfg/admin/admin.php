<?php
include '../conn.php';
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: ../login.php");
    exit;
}
$sql = "SELECT * FROM order_items ORDER BY created_at ASC LIMIT 30";
$result = $conn->query($sql);

$sales_data = [];
while ($row = $result->fetch_assoc()) {
    $sales_data[] = ['created_at' => $row['date_order'], 'price' => $row['total_price'], 'product_name' => $row['product_name'], 'quantity' => $row['quantity']];
}
$page = $_GET['page'] ?? 'dashboard';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Panel</title>
  <link rel="stylesheet" href="../styles.css">
  <style>
    body { display: flex; font-family: sans-serif; margin: 0; }
    nav.sidebar { width: 220px; background: #2c3e50; color: #fff; min-height: 100vh; }
    nav.sidebar a { display: block; color: #fff; padding: 15px; text-decoration: none; }
    nav.sidebar a:hover, nav.sidebar a.active { background: #34495e; }
    header.topnav { background: #ecf0f1; padding: 15px; width: 100%; display: flex; justify-content: space-between; align-items: center; }
    .main-content { flex: 1; background: #f8f9fa; padding: 20px; }
    
  </style>
</head>
<body>
  <nav class="sidebar">
    <h2 style="text-align:center; padding:10px 0;">Admin</h2>
    <a href="admin.php?page=dashboard" class="<?= $page == 'dashboard' ? 'active' : '' ?>">Dashboard</a>
    <a href="admin.php?page=products" class="<?= $page == 'products' ? 'active' : '' ?>">Products</a>
    <a href="admin.php?page=orders" class="<?= $page == 'orders' ? 'active' : '' ?>">Orders</a>
    <a href="admin.php?page=customers" class="<?= $page == 'customers' ? 'active' : '' ?>">Customers</a>
    <a href="admin.php?page=messages" class="<?= $page == 'messages' ? 'active' : '' ?>">Messages</a>
    <a href="../logout.php">Logout</a>
  </nav>

  <div class="main-content">
    <header class="topnav">
      <h1><?= ucfirst($page) ?></h1>
      <p>Welcome, Admin</p>
    </header>
    <section>
      <?php include "$page.php"; ?>
    </section>
  </div>
         
</body>
</html>