<?php
include '../conn.php';

$result = $conn->query("SELECT * FROM products ORDER BY id DESC");
?>

<h2>Manage Products</h2>
<form method="POST" action="../backend/create_product.php" style="margin-bottom:20px;">
  <input type="text" name="name" placeholder="Product Name" required>
  <input type="text" name="description" placeholder="Description" required>
  <input type="number" name="price" step="0.01" placeholder="Price" required>
  <input type="text" name="category" placeholder="Category" required>
  <input type="text" name="image_url" placeholder="Image URL" required>
  <button type="submit">Add Product</button>
</form>

<table border="1" cellpadding="8" cellspacing="0">
  <thead>
    <tr>
      <th>ID</th><th>Name</th><th>Description</th><th>Price</th><th>Category</th><th>Image</th><th>Status</th><th>Actions</th>
    </tr>
  </thead>
  <tbody>
    <?php while ($row = $result->fetch_assoc()): ?>
    <tr>
      <td><?= $row['id'] ?></td>
      <td><?= htmlspecialchars($row['name']) ?></td>
      <td><?= htmlspecialchars($row['description']) ?></td>
      <td>₱<?= number_format($row['price'], 2) ?></td>
      <td><?= $row['category'] ?></td>
      <td><img src="<?= $row['image_url'] ?>" width="60"></td>
      <td><?= $row['approved'] ? '✅ Approved' : '❌ Pending' ?></td>
      <td>
        <form method="GET" action="../backend/approve_product.php" style="display:inline;">
          <input type="hidden" name="id" value="<?= $row['id'] ?>">
          <input type="hidden" name="status" value="<?= $row['approved'] ? 0 : 1 ?>">
          <button type="submit"><?= $row['approved'] ? 'Reject' : 'Approve' ?></button>
        </form>
        <form method="POST" action="../backend/update_product.php" style="display:inline;">
          <input type="hidden" name="id" value="<?= $row['id'] ?>">
          <input type="hidden" name="name" value="<?= htmlspecialchars($row['name']) ?>">
          <input type="hidden" name="description" value="<?= htmlspecialchars($row['description']) ?>">
          <input type="hidden" name="price" value="<?= $row['price'] ?>">
          <input type="hidden" name="category" value="<?= $row['category'] ?>">
          <input type="hidden" name="image_url" value="<?= $row['image_url'] ?>">
          <button type="submit">Update</button>
        </form>
        <form method="GET" action="../backend/delete_product.php" style="display:inline;">
          <input type="hidden" name="id" value="<?= $row['id'] ?>">
          <button type="submit" onclick="return confirm('Delete this product?')">Delete</button>
        </form>
      </td>
    </tr>
    <?php endwhile; ?>
  </tbody>
</table>