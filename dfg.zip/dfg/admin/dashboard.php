<?php
include '../conn.php';

$totalOrders = $conn->query("SELECT COUNT(*) AS total_orders, SUM(total) AS total_sales FROM orders")->fetch_assoc();
$totalUsers = $conn->query("SELECT COUNT(*) AS total_users FROM users")->fetch_assoc();
$totalProducts = $conn->query("SELECT COUNT(*) AS total_products FROM products")->fetch_assoc();

$orderChart = $conn->query("SELECT DATE(created_at) as date, COUNT(*) as count FROM orders GROUP BY DATE(created_at) ORDER BY date DESC LIMIT 7");
$labels = [];
$values = [];
while ($row = $orderChart->fetch_assoc()) {
  $labels[] = $row['date'];
  $values[] = $row['count'];
}
?>

<div style="display: flex; gap: 20px; margin-bottom: 20px;">
  <div style="flex:1; background:#3498db; color:#fff; padding:20px;">
    <h3>Total Sales</h3>
    <p>₱<?= number_format($totalOrders['total_sales'], 2) ?></p>
  </div>
  <div style="flex:1; background:#2ecc71; color:#fff; padding:20px;">
    <h3>Total Orders</h3>
    <p><?= $totalOrders['total_orders'] ?></p>
  </div>
  <div style="flex:1; background:#e67e22; color:#fff; padding:20px;">
    <h3>Customers</h3>
    <p><?= $totalUsers['total_users'] ?></p>
  </div>
  <div style="flex:1; background:#9b59b6; color:#fff; padding:20px;">
    <h3>Products</h3>
    <p><?= $totalProducts['total_products'] ?></p>
  </div>
</div>

<canvas id="orderChart" height="100"></canvas>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
  const ctx = document.getElementById('orderChart').getContext('2d');
  const chart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: <?= json_encode(array_reverse($labels)) ?>,
      datasets: [{
        label: 'Orders per Day',
        data: <?= json_encode(array_reverse($values)) ?>,
        backgroundColor: '#2c3e50'
      }]
    },
    options: {
      responsive: true,
      scales: { y: { beginAtZero: true } }
    }
  });
</script>
<div class="dashboard-cards">
        <div class="analysis-section">
            <div class="section-header">
                <div class="section-title">Sales Analysis Report</div>
            </div>
            <div class="chart-row">
                <div class="chart-container">
                    <div class="chart-header">
                        <div class="chart-title">Monthly Sales (₱)</div>
                    </div>
                    <canvas id="salesChart"></canvas>
                </div>
                <div class="chart-container">
                    <div class="chart-header">
                        <div class="chart-title">Product Category Sales</div>
                    </div>
                    <canvas id="categoryChart"></canvas>
                </div>
            </div>
            <div class="chart-row">
                <div class="chart-container">
                    <div class="chart-header">
                        <div class="chart-title">Top Selling Products</div>
                    </div>
                    <canvas id="productChart"></canvas>
                </div>
            </div>
        </div>
     <script>
        const salesData = <?php echo json_encode($sales_data); ?>;

        const salesMap = salesData.reduce((acc, item) => {
            if (acc[item.date_order]) {
            acc[item.date_order] += parseFloat(item.total_price);
            } else {
            acc[item.date_order] = parseFloat(item.total_price);
            }
            return acc;
        }, {});

        const labels = Object.keys(salesMap);
        const amounts = Object.values(salesMap);
        const productMap = salesData.reduce((acc, item) => {
            if (acc[item.product_name]) {
            acc[item.product_name] += parseInt(item.quantity);
            } else {
            acc[item.product_name] = parseInt(item.quantity);
            }
            return acc;
        }, {});

        const product = Object.keys(productMap);
        const quantity = Object.values(productMap);
        
        document.addEventListener('DOMContentLoaded', function() {
            
            const salesCtx = document.getElementById('salesChart').getContext('2d');
            const salesChart = new Chart(salesCtx, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Sales (₱)',
                        data: amounts,
                        backgroundColor: 'rgba(39, 174, 96, 0.7)',
                        borderColor: 'rgba(39, 174, 96, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                drawBorder: false
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                }
            });
            
            const categoryCtx = document.getElementById('categoryChart').getContext('2d');
            const categoryChart = new Chart(categoryCtx, {
                type: 'pie',
                data: {
                    labels: product,
                    datasets: [{
                        data: quantity,
                        backgroundColor: [
                            'rgba(39, 174, 96, 0.7)',
                            'rgba(52, 152, 219, 0.7)',
                            'rgba(155, 89, 182, 0.7)',
                            'rgba(241, 196, 15, 0.7)',
                            'rgba(231, 76, 60, 0.7)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'right'
                        }
                    }
                }
            });
            
            const productCtx = document.getElementById('productChart').getContext('2d');
            const productChart = new Chart(productCtx, {
                type: 'bar',
                data: {
                    labels: product,
                    datasets: [{
                        data: amounts,
                        backgroundColor: 'rgba(52, 152, 219, 0.7)',
                        borderColor: 'rgba(52, 152, 219, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    indexAxis: 'y',
                    scales: {
                        x: {
                            beginAtZero: true,
                            grid: {
                                drawBorder: false
                            }
                        },
                        y: {
                            grid: {
                                display: false
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                }
            });
            
            document.getElementById('timePeriod').addEventListener('change', function() {
                const period = this.value;

                salesChart.data.datasets[0].data = salesData;
                categoryChart.data.datasets[0].data = categoryData;
                productChart.data.datasets[0].data = productData;
                paymentChart.data.datasets[0].data = paymentData;
                
                salesChart.update();
                categoryChart.update();
                productChart.update();
                paymentChart.update();
            });
        });
    </script>