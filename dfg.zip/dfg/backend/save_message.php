<?php
include '../conn.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user'])) {
    $user_id = $_SESSION['user']['id'];
    $sender = $conn->real_escape_string($_SESSION['user']['name']);
    $content = $conn->real_escape_string($_POST['message']);

    // Basic sentiment analysis
    function analyze_sentiment($message) {
        $positive_words = ['good', 'great', 'fast', 'thank', 'excellent', 'love', 'happy', 'fresh'];
        $negative_words = ['bad', 'late', 'poor', 'slow', 'hate', 'terrible', 'broken', 'angry'];

        $score = 0;
        $words = explode(' ', strtolower($message));
        foreach ($words as $word) {
            if (in_array($word, $positive_words)) $score++;
            if (in_array($word, $negative_words)) $score--;
        }

        if ($score > 0) return ['score' => $score, 'label' => 'positive'];
        if ($score < 0) return ['score' => $score, 'label' => 'negative'];
        return ['score' => 0, 'label' => 'neutral'];
    }

    $sentiment = analyze_sentiment($content);
    $score = $sentiment['score'];
    $label = $sentiment['label'];

    $stmt = $conn->prepare("INSERT INTO messages (user_id, sender, content, sentiment_score, sentiment_label) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("issis", $user_id, $sender, $content, $score, $label);
    $stmt->execute();

    header("Location: ../profile.php?msg=sent");
    exit;
}
?>