CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    description TEXT,
    price FLOAT,
    category VARCHAR(50),
    image_url VARCHAR(255),
    approved TINYINT DEFAULT 0
);