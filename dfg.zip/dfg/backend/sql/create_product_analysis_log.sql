CREATE TABLE IF NOT EXISTS product_analysis_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    log_date DATE DEFAULT CURRENT_DATE,
    total_products INT,
    approved INT,
    pending INT,
    total_orders INT,
    total_sales FLOAT,
    positive_messages INT,
    neutral_messages INT,
    negative_messages INT
);