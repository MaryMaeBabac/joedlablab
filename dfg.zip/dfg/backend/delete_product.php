<?php
include '../conn.php';
$id = intval($_GET['id']);
$conn->query("DELETE FROM products WHERE id = $id");
echo json_encode(["success" => true]);
?>