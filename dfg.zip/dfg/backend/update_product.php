<?php
include '../conn.php';

$data = json_decode(file_get_contents("php://input"), true);
$id = intval($data['id']);
$name = $conn->real_escape_string($data['name']);
$description = $conn->real_escape_string($data['description']);
$price = floatval($data['price']);
$category = $conn->real_escape_string($data['category']);
$image_url = $conn->real_escape_string($data['image_url']);

$sql = "UPDATE products SET 
        name = '$name',
        description = '$description',
        price = $price,
        category = '$category',
        image_url = '$image_url'
        WHERE id = $id";

$conn->query($sql);
echo json_encode(["success" => true]);
?>