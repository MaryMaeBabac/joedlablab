<?php
include '../conn.php';

$data = json_decode(file_get_contents("php://input"), true);
$name = $conn->real_escape_string($data['name']);
$description = $conn->real_escape_string($data['description']);
$price = floatval($data['price']);
$category = $conn->real_escape_string($data['category']);


$sql = "INSERT INTO products (name, description, price, category, image_url)
        VALUES ('$name', '$description', $price, '$category', '$image_url')";
$conn->query($sql);

echo json_encode(["success" => true]);
?>