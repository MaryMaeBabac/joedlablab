<?php
include '../conn.php';
$id = intval($_GET['id']);
$status = intval($_GET['status']);
$conn->query("UPDATE products SET approved = $status WHERE id = $id");
echo json_encode(["success" => true]);
?>