<?php
include 'conn.php';
session_start();

// Fetch only approved products
$result = $conn->query("SELECT * FROM products WHERE approved = 1 ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Castillano's </title>
  <link rel="stylesheet" href="styles.css" />
</head>
<body>
  <header>
    <h1>castillano's backyard</h1>
    <?php if (isset($_SESSION['user'])): ?>
      <p>Welcome, <?= $_SESSION['user']['name'] ?> | <a href="profile.php">Profile</a> | <a href="logout.php">Logout</a></p>
    <?php else: ?>
      <a href="login.php">Login</a> | <a href="register.php">Register</a>
    <?php endif; ?>
  </header>

  <main>
    <section class="product-grid">
      <?php while($row = $result->fetch_assoc()): ?>
        <div class="product-card">
          <img src="<?= htmlspecialchars($row['image_url']) ?>" alt="<?= htmlspecialchars($row['name']) ?>">
          <h3><?= htmlspecialchars($row['name']) ?></h3>
          <p><?= htmlspecialchars($row['description']) ?></p>
          <p><strong>₱<?= number_format($row['price'], 2) ?></strong></p>
          <form method="POST" action="cart.php">
            <input type="hidden" name="product_id" value="<?= $row['id'] ?>">
            <input type="number" name="qty" value="1" min="1" required>
            <button type="submit" name="add_to_cart">🛒 Add to Cart</button>
            <button type="submit" name="buy_now">📦 Buy Now</button>
          </form>
        </div>
      <?php endwhile; ?>
    </section>
  </main>
</body>
</html>