<?php
$conn = new mysqli("localhost", "root", "");
$db = mysqli_select_db($conn, "14");

?>
