<?php
include 'conn.php';
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user']['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];

    $sql = "UPDATE users SET name = '$name', email = '$email'";
    if (!empty($password)) {
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $sql .= ", password = '$hashed'";
    }
    $sql .= " WHERE id = $user_id";
    $conn->query($sql);

    $_SESSION['user']['name'] = $name;
    $_SESSION['user']['email'] = $email;
    $message = "Profile updated.";
}

// Fetch current user info from DB
$result = $conn->query("SELECT * FROM users WHERE id = $user_id");
$user = $result->fetch_assoc();
?>

<h2>Customer Profile</h2>
<?php if (!empty($message)) echo "<p style='color:green;'>$message</p>"; ?>

<form method="POST">
  <label>Name:</label><br>
  <input type="text" name="name" value="<?= htmlspecialchars($user['name']) ?>" required><br><br>
  <label>Email:</label><br>
  <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required><br><br>
  <label>New Password (leave blank to keep current):</label><br>
  <input type="password" name="password"><br><br>
  <button type="submit">Update Profile</button>
</form>