ALTER TABLE messages
ADD COLUMN sentiment_score INT DEFAULT 0,
ADD COLUMN sentiment_label VARCHAR(20) DEFAULT 'neutral';