-- USERS TABLE
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    password VARCHAR(255),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- PRODUCTS TABLE
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    description TEXT,
    price FLOAT,
    category VARCHAR(50),
    image_url VARCHAR(255),
    approved TINYINT DEFAULT 0
);

-- ORDERS TABLE
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    customer_name VARCHAR(100),
    address TEXT,
    phone VARCHAR(50),
    payment_method VARCHAR(50),
    total FLOAT,
    status VARCHAR(50) DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- ORDER ITEMS TABLE
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT,
    product_name VARCHAR(100),
    quantity INT,
    price FLOAT,
    FOREIGN KEY (order_id) REFERENCES orders(id)
);

-- MESSAGES TABLE
CREATE TABLE IF NOT EXISTS messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    sender VARCHAR(100),
    content TEXT,
    sentiment_score FLOAT DEFAULT 0,
    reply TEXT,
    sent_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- LOGIN HISTORY TABLE
CREATE TABLE IF NOT EXISTS login_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    login_time DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- PRODUCT ANALYSIS LOG TABLE
CREATE TABLE IF NOT EXISTS product_analysis_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    log_date DATE DEFAULT CURRENT_DATE,
    total_products INT,
    approved INT,
    pending INT,
    total_orders INT,
    total_sales FLOAT,
    positive_messages INT,
    neutral_messages INT,
    negative_messages INT
);

-- ADMINS TABLE
CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) UNIQUE,
    password VARCHAR(255)
);

-- Insert default admin
INSERT IGNORE INTO admins (email, password) VALUES ('admin@gmail.com', 'admin123');
-- Ensure admin user is available in users table for login redirect
INSERT IGNORE INTO users (name, email, password) 
VALUES ('Admin', 'admin@gmail.com', '$2b$12$W2biiNn.cTQHGO67mvA9iucBudJ.wGFhFUPGrYuHOcYHlHS/IDgM2');