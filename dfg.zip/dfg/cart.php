<?php
include 'conn.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = intval($_POST['product_id']);
    $product_name = $conn->real_escape_string($_POST['product_name']);
    $price = floatval($_POST['price']);
    $quantity = intval($_POST['quantity']);
    $total = $price * $quantity;

    // Fake user_id for demo (replace with real user session ID if available)
    $user_id = 1;

    // Insert into orders table
    $conn->query("INSERT INTO orders (user_id, customer_name, total, address, phone, payment_method, status)
                  VALUES ($user_id, '$product_name', $total, 'Demo Address', '0000000000', 'Cash on Delivery', 'pending')");
    $order_id = $conn->insert_id;

    // Insert into order_items table
    $conn->query("INSERT INTO order_items (order_id, product_name, quantity, price)
                  VALUES ($order_id, '$product_name', $quantity, $price)");

    if (isset($_POST['buy_now'])) {
        echo "<script>alert('Purchased successfully!'); window.location.href='index.php';</script>";
    } else {
        echo "<script>alert('Added to cart!'); window.location.href='index.php';</script>";
    }
} else {
    header('Location: index.php');
}
?>